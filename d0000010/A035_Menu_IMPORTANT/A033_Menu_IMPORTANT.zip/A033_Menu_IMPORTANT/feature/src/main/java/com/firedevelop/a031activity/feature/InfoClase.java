package com.firedevelop.a031activity.feature;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Production on 22/10/17.
 */

public class InfoClase extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);

    }
}