Tres en Raya - Curso de Android con Android Studio
==================================================

Píldoras Informáticas
---------------------
Profesor: Juan Gómez 

<a href="http://www.pildorasinformaticas.es" target="_blank">Web Píldoras Informáticas</a> - <a href="https://www.youtube.com/user/pildorasinformaticas" target="_blank">Canal Youtube</a> - <a href="https://www.youtube.com/playlist?list=PLU8oAlHdN5Bkn-KS1sRFlSEnXXcAtAJ9P" target="_blank">Curso Youtube</a>

Vista Previa
------------
<img src="https://s5.postimg.org/ub2rj7vbr/tresEnRaya.jpg" width="400px" alt="TresEnRaya">
<br>
<br>
<img src="https://s5.postimg.org/hxpxcb5nb/ticTacToe.jpg" width="400px" alt="TicTacToe">